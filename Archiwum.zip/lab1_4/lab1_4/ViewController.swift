//
//  ViewController.swift
//  lab1_4
//
//  Created by Ivan Filipchuk on 28/05/2023.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var liczba1: UITextField!
    @IBOutlet weak var liczba2: UITextField!
    @IBOutlet weak var result: UILabel!

    
    @IBAction func getResult(sender: UIButton){
        guard let l1 = Double(liczba1.text!), let l2 = Double(liczba2.text!) else {
            result.text = "Błędne dane"
            return
        }

        if l2 != 0{
            result.text = "Wynik: \(l1/l2)"
        }
        else{
            result.text = "Nie można dzielić przez zero!!!"
        }
    }
}

