//
//  ContentView.swift
//  lab1_5
//
//  Created by Ivan Filipchuk on 28/05/2023.
//

import SwiftUI

struct ContentView: View {
    @State var liczba1: String = ""
    @State var liczba2: String = ""
    @State var output: String = ""
    @State var errorMsg: Bool = false
    
    var body: some View {
        VStack (alignment: .leading){
            TextField("1 liczba ", text: $liczba1)
                .keyboardType(.decimalPad)
                .padding()
            
            TextField("2 liczba ", text: $liczba2)
                .keyboardType(.decimalPad)
                .padding()
            
            Button(action: {
                getResult()
            }, label: {
                Text("Oblicz")
            })
            .padding()
            
            
            if !output.isEmpty{
                Text("Wynik: \(output)")
                    .padding()
                    .font(.headline)
            }
        }
        .padding()
    }
    
    private func getResult(){
        guard let l1 = Double(liczba1), let l2 = Double(liczba2) else{
            output = String("Wpisana niepoprawna liczba")
            return
        }
        
        if l2 != 0 {
            output = String(l1 / l2)
        } else {
            output = String("Nie można dzielić przez zero!!!")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
