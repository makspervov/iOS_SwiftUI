//
//  lab1_5App.swift
//  lab1_5
//
//  Created by Ivan Filipchuk on 28/05/2023.
//

import SwiftUI

@main
struct lab1_5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
