//
//  ContentView.swift
//  lab2_4
//
//  Created by Maksym Pervov on 28/05/2023.
//

import SwiftUI

struct ContentView: View {
    @State private var number1 = ""
        @State private var number2 = ""
        @State private var operationIndex = 0
        @State private var result = ""

        let operations = ["+", "-", "*", "/"]

        var body: some View {
            VStack {
                TextField("Liczba 1", text: $number1)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                TextField("Liczba 2", text: $number2)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                Picker("Operacja", selection: $operationIndex) {
                    ForEach(0 ..< operations.count) {
                        Text(self.operations[$0])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                Button("Oblicz", action: calculate)
                    .padding()

                Text("Wynik: \(result)")
                    .padding()
            }
        }

        func calculate() {
            guard let num1 = Double(number1), let num2 = Double(number2) else {
                result = "Błędne dane"
                return
            }

            switch operationIndex {
            case 0:
                result = String(num1 + num2)
            case 1:
                result = String(num1 - num2)
            case 2:
                result = String(num1 * num2)
            case 3:
                if num2 == 0 {
                    result = "Dzielenie przez zero"
                } else {
                    result = String(num1 / num2)
                }
            default:
                result = "Nieznana operacja"
            }
        }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
