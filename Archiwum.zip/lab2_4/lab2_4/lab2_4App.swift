//
//  lab2_4App.swift
//  lab2_4
//
//  Created by Ivan Filipchuk on 28/05/2023.
//

import SwiftUI

@main
struct lab2_4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
