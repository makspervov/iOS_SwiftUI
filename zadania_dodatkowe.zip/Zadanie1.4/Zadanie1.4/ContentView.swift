//
//  ContentView.swift
//  Zadanie1.4
//
//  Created by student on 02/03/2023.
//

import SwiftUI

struct ContentView: View {
    
    @State var a: String = "";
    @State var b: String = "";
    @State var output: String = "Pole wynikowe";
    
    
    var body: some View {
        VStack {
                TextField("Liczba pierwsza",text: $a)
                TextField("Liczba druga",text: $b)
            Button("Zatwierdz"){
                let l1: Int? = Int(a);
                let l2: Int? = Int(b);
                
                if(l1 == nil || l2 == nil){
                    output = "Wynik"
                }else{
                    output = "=\n\(l1! * l2!)"
                }
            }
            
            Text(output)
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
