//
//  Zadanie1_4App.swift
//  Zadanie1.4
//
//  Created by student on 02/03/2023.
//

import SwiftUI

@main
struct Zadanie1_4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
