//
//  ContentView.swift
//  zadania
//
//  Created by student on 25/05/2023.
//

import SwiftUI

struct ContentView: View {
    @State var liczba1: String = ""
    @State var liczba2: String = ""
    @State var output: String = "Pole wynikowe";
    var body: some View {
        VStack (alignment: .leading){
            TextField("Podaj 1 liczbe ", text: $liczba1)
            TextField("Podaj 2 liczbe ", text: $liczba2)
            Text("Liczba 1 = \(Int(liczba1) ?? 0)")
            Text("Liczba 2 = \(Int(liczba2) ?? 0)")
            Button(action: {
                let l1: Int? = Int(liczba1);
                let l2: Int? = Int(liczba2);
                
                if(l1 == nil || l2 == nil){
                    output = "Wynik"
                }else{
                    output = "Pole wynikowe\n\(l1! * l2!)"
                }
            }
                   , label:{Text("Zatwierdz")})
        }
        Text(output)
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
