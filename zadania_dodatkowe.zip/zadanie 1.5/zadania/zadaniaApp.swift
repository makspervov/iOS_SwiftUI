//
//  zadaniaApp.swift
//  zadania
//
//  Created by student on 25/05/2023.
//

import SwiftUI

@main
struct zadaniaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
