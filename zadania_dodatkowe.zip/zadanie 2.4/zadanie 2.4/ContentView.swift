//
//  ContentView.swift
//  zadanie 2.4
//
//  Created by student on 25/05/2023.
//
import SwiftUI

struct ContentView: View {
@State private var number1 = ""
@State private var number2 = ""
@State private var selectedOperation = 0
@State private var result = ""

var body: some View {
VStack {
Text("KALKULATOR")
        .foregroundColor(.blue)
        .bold()
        .padding()
TextField("Liczba 1", text: $number1)
    .textFieldStyle(DefaultTextFieldStyle())


TextField("Liczba 2", text: $number2)
    .textFieldStyle(DefaultTextFieldStyle())


HStack {
    Button(action: {
    performOperation(.addition)
    }) {
        Text("+")
        .font(.largeTitle)
        .padding()
        .foregroundColor(.black)
    }

    Button(action: {
    performOperation(.subtraction)
    }) {
    Text("-")
            .font(.largeTitle)
            .padding()
            .foregroundColor(.black)
    }

    Button(action: {
    performOperation(.multiplication)
    }) {
    Text("*")
            .font(.largeTitle)
            .padding()
            .foregroundColor(.black)
    }

Button(action: {
performOperation(.division)
}) {
    Text("/")
            .font(.largeTitle)
            .padding()
            .foregroundColor(.black)
    }
    }
    .padding()

    if !result.isEmpty {
    Text(" = \(result)")
            .font(.largeTitle)
            .padding()
            .foregroundColor(.black)
}
}
}

private func performOperation(_ operation: Operation) {
guard let number1Value = Int(number1), let number2Value = Int(number2) else {
result = "Wprowadź poprawne liczby."
return
}

switch operation {
case .addition:
    result = "\(number1Value + number2Value)"
case .subtraction:
    result = "\(number1Value - number2Value)"
case .multiplication:
    result = "\(number1Value * number2Value)"
case .division:
if number2Value != 0 {
    result = "\(number1Value / number2Value)"
} else {
    result = "Nie dziel przez 0!"
}
}
}

private enum Operation {
case addition
case subtraction
case multiplication
case division
}
}

struct ContentView_Previews: PreviewProvider {
static var previews: some View {
ContentView()
}
}
