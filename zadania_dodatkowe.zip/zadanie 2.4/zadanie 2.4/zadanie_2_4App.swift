//
//  zadanie_2_4App.swift
//  zadanie 2.4
//
//  Created by student on 25/05/2023.
//

import SwiftUI

@main
struct zadanie_2_4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
